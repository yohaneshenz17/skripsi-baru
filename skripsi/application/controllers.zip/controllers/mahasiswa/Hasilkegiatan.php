<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hasilkegiatan extends MY_Controller {

	public function index()
	{
		return $this->load->view('mahasiswa/hasilkegiatan');
	}

}

/* End of file Hasilkegiatan.php */
/* Location: ./application/controllers/mahasiswa/Hasilkegiatan.php */