<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hasilkegiatan extends MY_Controller {

	public function index()
	{
		return $this->load->view('admin/hasilkegiatan');
	}

}

/* End of file Hasilkegiatan.php */
/* Location: ./application/controllers/admin/Hasilkegiatan.php */