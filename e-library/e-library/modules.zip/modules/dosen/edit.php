<?php
require_once '../../config/database.php';
require_once '../../config/functions.php';

requireLogin();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get dosen data
$query = "SELECT * FROM dosen WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($did, $nuptk, $nama, $prodi, $no_hp, $foto, $created, $updated);

if ($stmt->fetch()) {
    $stmt->close();
    $dosen = array(
        'id' => $did,
        'nuptk' => $nuptk,
        'nama' => $nama,
        'program_studi' => $prodi,
        'no_hp' => $no_hp,
        'foto' => $foto
    );
} else {
    $stmt->close();
    setAlert('danger', 'Dosen tidak ditemukan!');
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nuptk = sanitize($_POST['nuptk']);
    $nama = sanitize($_POST['nama']);
    $program_studi = sanitize($_POST['program_studi']);
    $no_hp = sanitize($_POST['no_hp']);
    
    // Handle foto upload
    $foto = $dosen['foto'];
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $upload = uploadFoto($_FILES['foto'], UPLOAD_DOSEN);
        if ($upload['success']) {
            if ($foto && file_exists(UPLOAD_DOSEN . $foto)) {
                unlink(UPLOAD_DOSEN . $foto);
            }
            $foto = $upload['filename'];
        }
    }
    
    // Update dosen
    $query = "UPDATE dosen SET nuptk = ?, nama = ?, program_studi = ?, no_hp = ?, foto = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssi", $nuptk, $nama, $program_studi, $no_hp, $foto, $id);
    
    if ($stmt->execute()) {
        $stmt->close();
        setAlert('success', 'Dosen berhasil diupdate!');
        header('Location: index.php');
        exit;
    } else {
        $stmt->close();
        setAlert('danger', 'Gagal mengupdate dosen!');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dosen - E-Library STK Yakobus</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <?php include '../../includes/navbar.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="bi bi-pencil me-2"></i>Edit Dosen</h1>
                </div>

                <?php showAlert(); ?>

                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">NUPTK <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nuptk" value="<?= $dosen['nuptk'] ?>" required>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nama" value="<?= $dosen['nama'] ?>" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Program Studi <span class="text-danger">*</span></label>
                                        <select class="form-select" name="program_studi" required>
                                            <option value="S1 Pendidikan Keagamaan Katolik" <?= $dosen['program_studi'] == 'S1 Pendidikan Keagamaan Katolik' ? 'selected' : '' ?>>S1 Pendidikan Keagamaan Katolik</option>
                                            <option value="S1 Pendidikan Guru Sekolah Dasar" <?= $dosen['program_studi'] == 'S1 Pendidikan Guru Sekolah Dasar' ? 'selected' : '' ?>>S1 Pendidikan Guru Sekolah Dasar</option>
                                            <option value="Profesi Pendidikan Guru PAK" <?= $dosen['program_studi'] == 'Profesi Pendidikan Guru PAK' ? 'selected' : '' ?>>Profesi Pendidikan Guru PAK</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">No. HP</label>
                                        <input type="text" class="form-control" name="no_hp" value="<?= $dosen['no_hp'] ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Foto</label>
                                <input type="file" class="form-control" name="foto" accept="image/*">
                                <small class="text-muted">Kosongkan jika tidak ingin mengubah foto</small>
                                <?php if ($dosen['foto']): ?>
                                <div class="mt-2">
                                    <img src="<?= BASE_URL ?>uploads/dosen/<?= $dosen['foto'] ?>" class="img-preview" alt="Foto">
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Update
                                </button>
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle me-2"></i>Batal
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>